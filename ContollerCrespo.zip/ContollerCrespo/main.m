%SETTING: Problem based on the ACC90 robust challenge. The limit state function g\in R^3 depends on the parameter p\in R^6 and the design variable d\in R^9 such that
%g(p,d)<0 implies that all 3 requirements are satisfied. g_1 is hurwitz stability, g_2 is impulse response and g_3 is control effort. p is free to vary between the
%limits prescribed in "plims". There are two models for evaluating g(p,d). The high-fidelity model corresponds to "use_lin_model=0", whereas the low-fidelity model
%corresponds to "use_lin_model=1". The low-fidelity model is independent of p(4). Publishable results require setup=2 or setup=3
%GOALS:
%1-Estimate the probability density of p, f_p, according to the observations in "psams"
%2-Find a value for d that minimizes the probability of failure corresponding to f_p
%AUTHOR: Luis G. Crespo, NASA LaRC, 0ct 24 2018
%Modified by: R.Rocchetta 2019
clear;close all;

%% Parameter p
pnom=[1,1,1,0,1,0.001];                                     % nominal p
names={'m_1','m_2','kl','kn','\lambda','\tau'};             % names of parameters
plims=[0.1,2;...
    0.1,2;...
    0.05,1.75;...
    -1,1;...
    0.2,1.8;...
    0.0001,0.3];%admissible ranges

%% Design variable d
load_d=0;
if load_d==1
    cd _privatefiles/
    comp='Z';  %A,B,C,D,E,F,H,W1,W2,Z
    dnom=numden2vec(getcomp(comp));
    cd ..
else
    dnom=[-0.1324 0.3533 0.6005 0.0728 0.5503 1.4175 2.6531 2.4802 1]; %nominal d (using W2 structure)
end

%% Time simulation setting
tvec=0:0.002:25;
setup=2; %1,2,3
if setup==1
    use_lin_model=1;uncertainty='small';  
elseif setup==2
    use_lin_model=1;uncertainty='large';
elseif setup==3
    use_lin_model=0;uncertainty='small'; % small uncertainty and non-linear model
elseif setup==4
    use_lin_model=0;uncertainty='large'; % large uncertainty and non-linear model
end

%% Comparing different models
compare=0;
if compare
    tic
    g1=evaluate_g2(pnom,dnom,use_lin_model,tvec,1); %Evaluating g using low-fidelity model and p(4)=0
    toc
    tic
    g2=evaluate_g2(pnom,dnom,use_lin_model,tvec,1); %Evaluating g using high-fidelity model and p(4)=0
    toc
    p=pnom;
    p(4)=-0.91;
    g3=evaluate_g2(p,dnom,1,tvec,1);   %Evaluating g using low-fidelity model and p(4)<<0
    % g4=evaluate_g2(p,dnom,0,tvec,1)    %Evaluating g using high-fidelity model and p(4)<<0
end

%% Load dataset and show samples
gendata=0;
if gendata
    cd _privatefiles/
    usize=0.35;
    psams=getpsams(usize);
    [plims(:,1),min(psams)',mean(psams)',max(psams)',plims(:,2)],
    cd ..
else
    if isequal(uncertainty,'small')
        load('syspars_smallu.mat','psams'); %usize=0.35;
    else
        load('syspars_largeu.mat','psams'); %usize=1
    end
end
figure
plotmatrix(psams);
%% eval for all the samples
[g_p]=g_ControllerCrespo(psams,dnom,use_lin_model);
%% Show 2d-sections of individual and overall safe/failure domains and superimpose observations
show_cuts=1;
if show_cuts
    nsteps=10; %
    activepos=[1,6]; %components of p being varied. Choose any 2 integers between 1 and 6
    vec1=plims(activepos(1),1):(plims(activepos(1),2)-plims(activepos(1),1))/nsteps:plims(activepos(1),2);
    vec2=plims(activepos(2),1):(plims(activepos(2),2)-plims(activepos(2),1))/nsteps:plims(activepos(2),2);
    fprintf(1,'%s','Making Cuts {...');
    for i=1:length(vec1)
        for j=1:length(vec2)
            p=pnom;
            p(activepos(1))=vec1(i); % assign the i-th value to factor activepos(1)
            p(activepos(2))=vec2(j); % assign the j-th value to factor activepos(2)
            g=evaluate_g2(p,dnom,use_lin_model,tvec,0);
            mat1(j,i)=g(1);
            mat2(j,i)=g(2);
            mat3(j,i)=g(3);
            mat_all(j,i)=max(g);
        end
    end
    fprintf(1,'%s\n','}');
    %set(figure,'Position',[300 600 1200 600]);
    subplot(141);
    surf(vec1,vec2,sign(mat1));shading flat;colormap jet;view(2);
    xlabel(names(activepos(1)));ylabel(names(activepos(2)));title('Stability');set(gca,'FontName','Arial','FontSize',20);axis tight;
    subplot(142);
    surf(vec1,vec2,sign(mat2));shading flat;colormap jet;view(2);
    xlabel(names(activepos(1)));title('Impulse response');set(gca,'FontName','Arial','FontSize',20);axis tight;
    subplot(143);
    surf(vec1,vec2,sign(mat3));shading flat;colormap jet;view(2);
    xlabel(names(activepos(1)));title('Control effort');set(gca,'FontName','Arial','FontSize',20);axis tight;
    subplot(144);
    surf(vec1,vec2,sign(mat_all));shading flat;colormap jet;view(2);colorbar;hold on;
    plot3(psams(:,activepos(1)),psams(:,activepos(2)),psams(:,activepos(2))*0+2,'w.');axis tight;
    xlabel(names(activepos(1)));title('All Reqs');set(gca,'FontName','Arial','FontSize',20);
end

%Evaluating probability of failure from samples
for i=1:size(psams,1)
    g(i,:)=evaluate_g2(psams(i,:),dnom,use_lin_model,tvec,0);
end
prob_fail_req1=sum(g(:,1)>0)/size(g,1) % G>0 is failure?
prob_fail_req2=sum(g(:,2)>0)/size(g,1)
prob_fail_req3=sum(g(:,1)>0)/size(g,1)
prob_fail_anyreq=sum(max(g')'>0)/size(g,1)
